"""
tabs/classical.py — render() for tab_classical.
"""

import streamlit as st


def render():
    st.markdown("## Classical radar detection: CA-CFAR + Kalman tracker")
    st.markdown(
        "Before introducing machine learning it is useful to understand the standard pipeline "
        "it replaces — and why that pipeline is difficult to improve without changing the "
        "underlying architecture."
    )

    st.divider()

    # ── Signal chain ──────────────────────────────────────────────────────────
    st.markdown("### 1 — The signal chain")
    st.markdown(
        "A rotating surveillance radar illuminates the scene in a sequence of narrow azimuth "
        "beams. For each beam it transmits a short pulse and records the echo amplitude at "
        "each range gate as the pulse return window slides forward in time. The result after "
        "one full 360° rotation is a **Plan Position Indicator (PPI) sweep** — a 2-D grid of "
        "amplitude samples indexed by (azimuth, range)."
    )
    st.code(
        "One rotation = one PPI sweep  (n_az × n_range  amplitude samples)\n"
        "Ten rotations = the sequence used for detection in this demo\n"
        "\n"
        "  Azimuth resolution:  2°  (180 bins per sweep)\n"
        "  Range resolution:    7.5 m  (64 bins, ≈ 480 m max range)\n"
        "  Rotation period:     2 s  (30 RPM)",
        language="text",
    )

    st.divider()

    # ── CA-CFAR ───────────────────────────────────────────────────────────────
    st.markdown("### 2 — Cell-Averaging CFAR (CA-CFAR)")
    st.markdown(
        "**CFAR** stands for *Constant False Alarm Rate*. The idea is that a target detection "
        "threshold should automatically adapt to the local noise level — otherwise a fixed "
        "threshold would produce too many false alarms in strong clutter and miss targets in "
        "quiet regions."
    )

    col_cfar_txt, col_cfar_eq = st.columns([3, 2])
    with col_cfar_txt:
        st.markdown(
            "For each **cell under test (CUT)**, CA-CFAR computes a noise estimate from the "
            "surrounding **reference cells**, excluding a **guard band** that protects against "
            "the target's own sidelobe energy leaking into the reference window:"
        )
        st.markdown(
            "- Reference cells: the N cells surrounding the guard ring\n"
            "- Guard cells: a small exclusion zone around the CUT\n"
            "- Noise estimate: Z = mean amplitude across all reference cells\n"
            "- Detection threshold: **T = α · Z**\n"
            "- Detection if CUT > T, otherwise no detection"
        )
        st.markdown(
            "The constant **α** is derived analytically to achieve a target false alarm "
            "probability *Pfa* — hence *Constant False Alarm Rate*. "
            "In this demo: guard = 2 cells, reference = 5 cells each side, α = 2.5."
        )
    with col_cfar_eq:
        st.code(
            "# 2-D CA-CFAR (per sweep)\n"
            "for each cell (az, r):\n"
            "    ref = cells in ring(az±7, r±7)\n"
            "         excluding guard ring\n"
            "    Z   = mean(ref)\n"
            "    T   = α * Z\n"
            "    det[az,r] = (cell > T)",
            language="python",
        )

    st.markdown(
        "**Where it works:** CFAR is mathematically optimal when background noise is "
        "homogeneous (all reference cells drawn from the same distribution). For an isolated "
        "target in Rayleigh-distributed clutter with sufficient SNR it achieves very close "
        "to the theoretical Pd curve."
    )
    st.warning(
        "**Where it fails:** The homogeneity assumption breaks down in real coastal and "
        "littoral environments. A reference window straddling a sea-land boundary, a rain "
        "cell, or a vessel wake mixes two different noise distributions. The resulting noise "
        "estimate is wrong — producing either excessive false alarms (underestimate) or "
        "missed detections (overestimate). This failure mode is *fundamental to the "
        "algorithm* and cannot be fixed by tuning α."
    )

    st.divider()

    # ── Kalman filter tracker ─────────────────────────────────────────────────
    st.markdown("### 3 — Kalman filter tracker")
    st.markdown(
        "A single CFAR sweep produces hundreds of detections per rotation — most of them "
        "noise. The **Kalman filter tracker** converts the noisy binary detection map into "
        "confirmed tracks by requiring *spatial and temporal consistency*."
    )

    col_kf1, col_kf2 = st.columns(2)
    with col_kf1:
        st.markdown("**State vector per track:**")
        st.code(
            "x = [range_bin,     # estimated radial position\n"
            "     range_rate,    # bins/sweep\n"
            "     azimuth_bin,   # estimated angular position\n"
            "     azimuth_rate]  # bins/sweep",
            language="python",
        )
        st.markdown("**Predict–update cycle (per sweep):**")
        st.code(
            "# Predict\n"
            "x_pred = F @ x_prev          # kinematics\n"
            "P_pred = F @ P_prev @ F.T + Q # process noise\n"
            "\n"
            "# Associate\n"
            "for each new detection d:\n"
            "    dist = euclidean(d, x_pred)\n"
            "    if dist < gate:            # 8-bin gate\n"
            "        update(x, P, d)        # standard KF\n"
            "\n"
            "# Confirm\n"
            "if track.hits >= 4:  # M-of-N rule\n"
            "    confirm(track)             # report to operator",
            language="python",
        )
    with col_kf2:
        st.markdown("**Why ≥ 4 hits?**")
        st.markdown(
            "A random noise spike that triggers CFAR in one sweep is unlikely to appear in "
            "the same location next sweep, and the sweep after that. Requiring *at least 4 "
            "consistent associations within an 8-bin gate* reduces the false track rate by "
            "several orders of magnitude compared to reporting every CFAR hit directly."
        )
        st.markdown("**Classical pipeline summary:**")
        st.code(
            "raw PPI sweep\n"
            "  → CFAR  (binary detection map)\n"
            "  → peak extraction  (centroid of each blob)\n"
            "  → KF predict  (forward-project existing tracks)\n"
            "  → nearest-neighbour association\n"
            "  → KF update\n"
            "  → confirm if hits ≥ 4\n"
            "  → confirmed track (position + velocity)",
            language="text",
        )

    st.divider()

    # ── Limitations summary ───────────────────────────────────────────────────
    st.markdown("### 4 — Operational limitations")
    col_lim1, col_lim2, col_lim3 = st.columns(3)
    with col_lim1:
        st.markdown("**Low SNR performance**")
        st.markdown(
            "CFAR applies a threshold independently to each sweep. When the target echo "
            "barely clears the noise floor, CFAR misses it most sweeps and the KF never "
            "accumulates enough hits to confirm. The ML pipeline integrates evidence across "
            "sweeps through a learned representation — achieving full detection "
            "several decibels lower."
        )
    with col_lim2:
        st.markdown("**Heterogeneous clutter**")
        st.markdown(
            "Reference window contamination at clutter boundaries floods the display with "
            "false alarms. The KF suppresses most of them but confirmed false tracks still "
            "reach the operator. CFAR has no mechanism to learn or adapt to a specific "
            "clutter environment — the noise model is fixed at algorithm design time."
        )
    with col_lim3:
        st.markdown("**Fixed operating point**")
        st.markdown(
            "α is a scalar constant. Changing the operating point (Pfa vs Pd trade-off) "
            "requires re-deriving and redeploying the constant. An ML detector outputs a "
            "continuous confidence score that can be thresholded post-hoc at any operating "
            "point — the ROC curve is swept by adjusting the threshold, not the model."
        )

    st.info(
        "**Next tab →** The bridge from CFAR to ML: how the problem is reframed as a "
        "classification task, what training data is needed, and which architecture is used."
    )
